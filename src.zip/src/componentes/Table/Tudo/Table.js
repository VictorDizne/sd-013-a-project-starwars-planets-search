// import React, { useContext } from 'react';
// import contextApp from '../context/contextApp';
// import FilterName from './filterName';

// import TableLinhas from './Table/TableLinhas';

// function TableHeader() {
//   const { data } = useContext(contextApp);

//   return (
//     <section>
//       <div>
//         <FilterName />
//       </div>
//       <div>
//         <table>
//           <thead>
//             <tr>
//               <th>name</th>
//               <th>rotation_period</th>
//               <th>orbital_period</th>
//               <th>diameter</th>
//               <th>climate</th>
//               <th>gravity</th>
//               <th>terrain</th>
//               <th>surface_water</th>
//               <th>population</th>
//               <th>films</th>
//               <th>created</th>
//               <th>edited</th>
//               <th>url</th>
//             </tr>
//           </thead>
//           <TableLinhas data={data} />
//         </table>

//       </div>
//     </section>
//   );
// }

// export default TableHeader;
