import { createContext } from 'react';

const contextApp = createContext();

export default contextApp;
