import { createContext } from 'react';

const PlanetContext = createContext();

export default PlanetContext;
